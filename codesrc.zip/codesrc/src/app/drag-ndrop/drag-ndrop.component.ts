import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drag-ndrop',
  templateUrl: './drag-ndrop.component.html',
  styleUrls: ['./drag-ndrop.component.css']
})
export class DragNDropComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

}
